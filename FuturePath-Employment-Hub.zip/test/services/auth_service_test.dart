import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:futurepath_employment_hub/services/auth_services.dart';

class MockGoTrueClient extends Mock implements GoTrueClient {}

void main() {
  late MockGoTrueClient authClient;
  late AuthService authService;

  setUp(() {
    authClient = MockGoTrueClient();
    authService = AuthService.withClient(authClient);
  });

  group('AuthService', () {
    test('isLoggedIn is false when there is no current session', () {
      when(() => authClient.currentSession).thenReturn(null);

      expect(authService.isLoggedIn, isFalse);
    });

    test('logout delegates to Supabase signOut', () async {
      when(() => authClient.signOut()).thenAnswer((_) async {});

      await authService.logout();

      verify(() => authClient.signOut()).called(1);
    });

    test('resetPassword forwards email and redirect URL', () async {
      when(
        () => authClient.resetPasswordForEmail(
          any(),
          redirectTo: any(named: 'redirectTo'),
        ),
      ).thenAnswer((_) async {});

      await authService.resetPassword(email: 'jose@example.com');

      verify(
        () => authClient.resetPasswordForEmail(
          'jose@example.com',
          redirectTo: AuthService.passwordResetRedirectUrl,
        ),
      ).called(1);
    });
  });
}