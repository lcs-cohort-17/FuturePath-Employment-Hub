// Flutter web plugin registrant file.
//
// Generated file. Do not edit.
//

// @dart = 2.13
// ignore_for_file: type=lint

import 'package:app_links_web/app_links_web.dart';
import 'package:device_info_plus/src/device_info_plus_web.dart';
import 'package:file_picker/_internal/file_picker_web.dart';
import 'package:package_info_plus/src/package_info_plus_web.dart';
import 'package:passkeys_web/passkeys_web.dart';
import 'package:shared_preferences_web/shared_preferences_web.dart';
import 'package:ua_client_hints/ua_client_hints_web.dart';
import 'package:url_launcher_web/url_launcher_web.dart';
import 'package:flutter_web_plugins/flutter_web_plugins.dart';

void registerPlugins([final Registrar? pluginRegistrar]) {
  final Registrar registrar = pluginRegistrar ?? webPluginRegistrar;
  AppLinksPluginWeb.registerWith(registrar);
  DeviceInfoPlusWebPlugin.registerWith(registrar);
  FilePickerWeb.registerWith(registrar);
  PackageInfoPlusWebPlugin.registerWith(registrar);
  PasskeysWeb.registerWith(registrar);
  SharedPreferencesPlugin.registerWith(registrar);
  UaClientHintsWeb.registerWith(registrar);
  UrlLauncherPlugin.registerWith(registrar);
  registrar.registerMessageHandler();
}
