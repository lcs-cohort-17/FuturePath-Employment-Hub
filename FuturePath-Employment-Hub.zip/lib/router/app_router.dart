import 'package:flutter/material.dart';

import '../screens/auth/forgot_password_screen.dart';
import '../screens/auth/login_screen.dart';
import '../screens/auth/reset_password_screen.dart';
import '../screens/auth/sign_up_screen.dart';
import '../screens/shell/main_shell.dart';
import '../services/auth_services.dart';

class AppRouter {
  AppRouter._();

  static final GlobalKey<NavigatorState> navigatorKey =
      GlobalKey<NavigatorState>();

  static const String login = '/login';
  static const String signup = '/signup';
  static const String forgotPassword = '/forgot-password';
  static const String resetPassword = '/reset-password';
  static const String home = '/home';

  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case login:
        return _buildRoute(
          settings: settings,
          child: const LoginScreen(),
        );

      case signup:
        return _buildRoute(
          settings: settings,
          child: const SignupScreen(),
        );

      case forgotPassword:
        return _buildRoute(
          settings: settings,
          child: const ForgotPasswordScreen(),
        );

      case resetPassword:
        return _buildRoute(
          settings: settings,
          child: const ResetPasswordScreen(),
        );

      case home:
        if (!AuthService().hasActiveSession) {
          return _buildRoute(
            settings: const RouteSettings(name: login),
            child: const LoginScreen(),
          );
        }

        return _buildRoute(
          settings: settings,
          child: const AppShell(),
        );

      default:
        return _buildRoute(
          settings: const RouteSettings(name: login),
          child: const LoginScreen(),
        );
    }
  }

  static MaterialPageRoute<dynamic> _buildRoute({
    required RouteSettings settings,
    required Widget child,
  }) {
    return MaterialPageRoute<dynamic>(
      settings: settings,
      builder: (_) => child,
    );
  }
}