import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// The single service responsible for communicating with Supabase Auth.
class AuthService {
  AuthService._([this._injectedAuth]);

  AuthService.withClient(GoTrueClient auth) : _injectedAuth = auth;

  static final AuthService _instance = AuthService._();

  factory AuthService() => _instance;

  static const String passwordResetRedirectUrl =
      'io.futurepath://reset-password';

  final GoTrueClient? _injectedAuth;

  // Resolve Supabase lazily so UI-only widget tests can construct screens
  // without initializing Supabase first. Production still uses the singleton.
  GoTrueClient get _auth =>
      _injectedAuth ?? Supabase.instance.client.auth;

  Stream<AuthState> get authStateChanges => _auth.onAuthStateChange;

  bool get hasActiveSession => _auth.currentSession != null;

  // Kept for compatibility with existing branch code.
  bool get isLoggedIn => hasActiveSession;

  String? get userEmail => _auth.currentUser?.email;

  User? get currentUser => _auth.currentUser;

  Future<AuthResponse> signIn({
    required String email,
    required String password,
  }) {
    return _auth.signInWithPassword(
      email: email,
      password: password,
    );
  }

  Future<AuthResponse> signUp({
    required String email,
    required String password,
  }) {
    return _auth.signUp(
      email: email,
      password: password,
    );
  }

  Future<void> signOut() {
    return _auth.signOut();
  }

  Future<void> logout() {
    return signOut();
  }

  Future<void> resetPassword({
    required String email,
    String redirectTo = passwordResetRedirectUrl,
  }) {
    return _auth.resetPasswordForEmail(
      email,
      redirectTo: redirectTo,
    );
  }

  Future<void> updatePassword(String newPassword) async {
    await _auth.updateUser(
      UserAttributes(password: newPassword),
    );
  }
}

final authServiceProvider = Provider<AuthService>((ref) => AuthService());